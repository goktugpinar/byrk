<?php

/********************************* Back Files *********************************/
// overview.php

$lang["title_flags"] = "Flags";
$lang["title_new_flag"] = "New Flag";
$lang["title_edit_flag"] = "Edit Flag";
$lang["button_new_flag"] = "New Flag";

$lang["tbl_title_country"] = "Flag country";
$lang["tbl_title_image"] = "Flag image";
$lang["tbl_title_order"] = "Order";
$lang["tbl_title_action"] = "Action";

// create.php, edit.php and edit_picture.php

$lang["title_new_flag"] = "New Flag";
$lang["title_edit_flag"] = "Edit Flag";

$lang["input_country"] = "Country";
$lang["input_image"] = "Image";
$lang["input_wikipedia"] = "Wikipedia Link";
$lang["input_status"] = "Status";
$lang["input_active"] = "Active";


/********************************* Front Files *********************************/