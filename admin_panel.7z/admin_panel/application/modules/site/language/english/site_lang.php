<?php

/********************************* Back Files *********************************/


$lang["title_edit_profile"] = "Edit Profile";

$lang["input_username"] = "Username";
$lang["input_old_password"] = "Old password";
$lang["input_password"] = "New password";
$lang["input_password_conf"] = "Re-type password";
$lang["input_market_link"] = "Market link";

$lang["page_title"] = "Who knows this flag?";
$lang["content_title"] = "Who knows this flag?";
$lang["enjoy_game"] = "Enjoy Flags Quiz game!";
$lang["install_from_google_play"] = "Install from google play";


/********************************* Front Files *********************************/